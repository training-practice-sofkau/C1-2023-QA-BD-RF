package com.sofkaU;

import com.sofkaU.integration.database.mysql.*;

import java.sql.*;
import java.lang.*;
public class Main {
    public static void main(String[] args) throws SQLException {
        Customer customer = new Customer();
        customer.createCustomer();

        Employee employee = new Employee();
        employee.createEmployee();

        Appointment appointment = new Appointment();
        appointment.createAppointment();

        Service_history serviceHistory = new Service_history();
        serviceHistory.createService();

        Supplier supplier = new Supplier();
        supplier.createSupplier();

        Product product = new Product();
        product.createProduct();

        Employee_Appointment employee_appointment = new Employee_Appointment();
        employee_appointment.createEmployee_Appointment();

        Sale_Product sale_product = new Sale_Product();
        sale_product.createSale_Product();

        Phone_Customer phone_customer = new Phone_Customer();
        phone_customer.create_Telefono_cliente();

        Product_Sale_Product product_sale_product = new Product_Sale_Product();
        product_sale_product.create_producto_vemte_producto();
    }
}