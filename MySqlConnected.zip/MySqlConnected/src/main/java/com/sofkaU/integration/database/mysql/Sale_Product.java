package com.sofkaU.integration.database.mysql;

import com.github.javafaker.DateAndTime;
import com.github.javafaker.Faker;

import java.sql.Date;
import java.sql.SQLException;
import java.time.Instant;
import java.time.LocalDate;

public class Sale_Product {

    Connetion connetion = new Connetion();


    public void createSale_Product() throws SQLException {
        Faker faker = new Faker();

        for (int i = 1; i <= 50; i++) {
            String id = String.valueOf(i);
            String nombre = faker.beer().name();
            DateAndTime fecha_venta = faker.date();
            connetion.sqlOperation();
            connetion.getStatement().executeUpdate(String.format("insert into venta_producto VALUES ( '%s', '%s', '%s', '%s')", id, fecha_venta , id, id));
        }
        connetion.close();
    }
}
