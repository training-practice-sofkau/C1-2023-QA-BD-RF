package com.sofkaU.integration.database.mysql;

import com.github.javafaker.Address;
import com.github.javafaker.Faker;
import com.github.javafaker.IdNumber;
import com.github.javafaker.Name;
import com.github.javafaker.Number;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Customer {
    Connetion connetion = new Connetion();


    public void createCustomer() throws SQLException {
        Faker faker = new Faker();

        for (int i = 1; i <= 50; i++) {
            String customerid = String.valueOf(i);
            String nombre = faker.name().firstName();
            String cedula = faker.idNumber().valid();
            String direccion = faker.address().city();
            String edad = faker.number().digit();
            connetion.sqlOperation();
            connetion.getStatement().executeUpdate(String.format("insert into cliente VALUES ('%s', '%s', '%s', '%s', '%s')", customerid, nombre, cedula , direccion, edad));
        }
        connetion.close();
    }
}
