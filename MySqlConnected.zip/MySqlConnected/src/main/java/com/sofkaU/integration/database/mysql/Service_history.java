package com.sofkaU.integration.database.mysql;

import com.github.javafaker.Faker;

import java.sql.SQLException;

public class Service_history {
    Connetion connetion = new Connetion();

    public void createService() throws SQLException {

        Faker faker = new Faker();

        for (int i = 1; i <= 50; i++) {
            String ID = String.valueOf(i);
             String hora = String.valueOf(faker.number().randomDigit());
            connetion.sqlOperation();
            connetion.getStatement().executeUpdate(String.format("insert into historial_servicio VALUES ('%s', '%s', '%s')", ID, hora, ID));
        }
        connetion.close();
    }
}
