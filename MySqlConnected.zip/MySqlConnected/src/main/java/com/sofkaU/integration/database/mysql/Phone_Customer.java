package com.sofkaU.integration.database.mysql;

import com.github.javafaker.DateAndTime;
import com.github.javafaker.Faker;

import java.sql.SQLException;

public class Phone_Customer {
    Connetion connetion = new Connetion();


    public void create_Telefono_cliente() throws SQLException {
        Faker faker = new Faker();

        for (int i = 1; i <= 50; i++) {
            String id = String.valueOf(i);
            String telefono_cliente = faker.phoneNumber().cellPhone();
            connetion.sqlOperation();
            connetion.getStatement().executeUpdate(String.format("insert into telefono_cliente VALUES ( '%s', '%s')", telefono_cliente ,id));
        }
        connetion.close();
    }
}
