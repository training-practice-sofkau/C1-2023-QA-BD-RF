package com.sofkaU.integration.database.mysql;

import com.github.javafaker.Faker;

import java.sql.SQLException;

public class Product_Sale_Product {
    Connetion connetion = new Connetion();


    public void create_producto_vemte_producto() throws SQLException {
        Faker faker = new Faker();

        for (int i = 1; i <= 50; i++) {
            String id = String.valueOf(i);
            String telefono_cliente = faker.phoneNumber().cellPhone();
            connetion.sqlOperation();
            connetion.getStatement().executeUpdate(String.format("insert into producto_venta_producto VALUES ( '%s', '%s')", id ,id));
        }
        connetion.close();
    }
}
