package com.sofkaU.integration.database.mysql;

import com.github.javafaker.Faker;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Appointment {
    Connetion connetion = new Connetion();

    public void createAppointment() throws SQLException {

        Faker faker = new Faker();

        for (int i = 1; i <= 50; i++) {
            String ID = String.valueOf(i);
            String hora = faker.number().digit();
            String fecha = faker.number().digit();
            connetion.sqlOperation();
            connetion.getStatement().executeUpdate(String.format("insert into cita VALUES ('%s', '%s', '%s','%s')", ID, hora, fecha, ID));
        }
        connetion.close();
    }
}
