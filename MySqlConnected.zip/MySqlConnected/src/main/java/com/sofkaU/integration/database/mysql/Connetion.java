package com.sofkaU.integration.database.mysql;

import java.sql.*;

public class Connetion {
    private static final String URL = "jdbc:mysql://localhost:3306/barberia";
    private static final String username = "root";
    private static final String password = "onpjd9bf";


    private Connection connection;

    private Statement statement;


    public Statement getStatement() {
        return statement;
    }


    public void sqlOperation() throws SQLException {
        connection = DriverManager.getConnection(URL, username, password);
        statement = connection.createStatement();
    }

    public void close() throws SQLException {
        connection.close();
        statement.close();
    }
}
