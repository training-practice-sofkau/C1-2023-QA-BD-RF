package com.sofkaU.integration.database.mysql;

import com.github.javafaker.Faker;

import java.sql.SQLException;

public class Supplier {

    Connetion connetion = new Connetion();


    public void createSupplier() throws SQLException {
        Faker faker = new Faker();

        for (int i = 1; i <= 50; i++) {
            String id = String.valueOf(i);
            String nombre = faker.name().firstName();
            String telefono = faker.phoneNumber().phoneNumber();
            String direccion = faker.address().city();
            connetion.sqlOperation();
            connetion.getStatement().executeUpdate(String.format("insert into proveedor VALUES ('%s', '%s', '%s', '%s')", id, nombre, telefono , direccion));
        }
        connetion.close();
    }
}
