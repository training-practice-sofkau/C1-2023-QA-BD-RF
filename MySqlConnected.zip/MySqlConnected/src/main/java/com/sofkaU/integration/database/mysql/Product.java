package com.sofkaU.integration.database.mysql;

import com.github.javafaker.Faker;

import java.sql.SQLException;

public class Product {

    Connetion connetion = new Connetion();


    public void createProduct() throws SQLException {
        Faker faker = new Faker();

        for (int i = 1; i <= 50; i++) {
            String id = String.valueOf(i);
            String nombre = faker.beer().name();
            int precioProducto = faker.number().numberBetween(1000,100000);
            int cantidadProducto = faker.number().randomDigit();
            connetion.sqlOperation();
            connetion.getStatement().executeUpdate(String.format("insert into producto VALUES ('%s', '%s', '%s', '%s', '%s')", id, nombre, precioProducto , cantidadProducto, id));
        }
        connetion.close();
    }
}
