package com.sofkaU.integration.database.mysql;

import com.github.javafaker.Faker;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Employee {
    Connetion connetion = new Connetion();

    public void createEmployee() throws SQLException {
        Faker faker = new Faker();

        for (int i = 0; i <= 50; i++) {
            String ID = String.valueOf(i);
            String nombre = faker.name().firstName();
            String cedula = faker.idNumber().valid();
            connetion.sqlOperation();
            connetion.getStatement().executeUpdate(String.format("insert into empleado VALUES ('%s', '%s', '%s')", ID, nombre, cedula));
        }
        connetion.close();
    }
}
