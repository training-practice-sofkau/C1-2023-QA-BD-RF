package com.sofkaU.integration.database.mysql;

import com.github.javafaker.Faker;

import java.sql.SQLException;

public class Employee_Appointment {

    Connetion connetion = new Connetion();

    public void createEmployee_Appointment() throws SQLException {

        Faker faker = new Faker();

        for (int i = 1; i <= 50; i++) {
            String ID = String.valueOf(i);
            connetion.sqlOperation();
            connetion.getStatement().executeUpdate(String.format("insert into empleado_cita      VALUES ('%s', '%s')", ID, ID));
        }
        connetion.close();
    }
}
